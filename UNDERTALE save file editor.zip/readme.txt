This is for editing your save file for undertale (if you couldn't tell).
If you have any questions or have any errors, talk to me on discord on my friend's server https://discord.gg/BZJT2fA7 (my name will be ieatdirt).
I don't know if this program will work on a mac.
There's this strange thing that happens to me when I change my name, it will apear as my name in the inventory but not in the title screen and when I save.